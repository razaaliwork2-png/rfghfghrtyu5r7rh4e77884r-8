import React from 'react';

export const DemoWatermark: React.FC = () => {
  return (
    <div className="demo-watermark">
      For demonstration only
    </div>
  );
};